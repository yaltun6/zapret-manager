Copy "nfq" folder here !
